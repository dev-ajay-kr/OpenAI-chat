package com.devajaykr.myapplication

data class Message(val text: String, val isFromUser: Boolean)
