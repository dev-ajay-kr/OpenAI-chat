


object OpenAI {
    private const val API_KEY = "YOUR_API_KEY_HERE"
    private const val API_URL = "https://api.openai.com/v1/images/generations"

    fun sendMessage(message: String): String {
        val params = listOf(
            "prompt" to message,
            "model" to "text-davinci-002",
            "max_tokens" to "1024"
        )

        val (request, response, result) = Fuel.post(API_URL)
            .header("Content-Type" to "application/json")
            .header("Authorization" to "Bearer $API_KEY")
            .body(params.toMap().toString())
            .responseString()

        return when (result) {
            is Result.Success -> {
                val data = result.get().fromJson<Map<String, Any>>()
                data["data"] as List<Map<String, Any>>
                val text = data["text"] as String
                text
            }
            is Result.Failure -> {
                "Error: ${result.getException()}"
            }
            else -> {return "ok"}
        }
    }
}

inline fun <reified T> String.fromJson(): T = Gson().fromJson(this, T::class.java)
